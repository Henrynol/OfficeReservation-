import React from 'react';
import Navbar from './components/Navbar';
import Login from './components/Login';
import Footer from './components/Footer';
import './App.css'; // Main global styles

function App() {
    return (
        <div className="App">
            {/* Navbar Component */}
            <Navbar />
            {/* Login Component */}
            <Login />
            {/* Footer Component */}
            <Footer />
        </div>
    );
}

export default App;
