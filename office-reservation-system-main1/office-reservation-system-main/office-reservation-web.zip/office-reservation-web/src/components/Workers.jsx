import styles from "../styles/Workers.module.css";
import React from "react";

const Workers = () =>{
    return(
        <div className={styles.workersContainer}>
            <div className={styles.employeeContainer}>
                <div className={styles.picture}>
                </div>
                <div className={styles.info}>
                    <p>Name</p>
                    <p>info</p>
                </div>
            </div>
            <div className={styles.employeeContainer}>
                <div className={styles.picture}>
                </div>
                <div className={styles.info}>
                    <p>Name</p>
                    <p>info</p>
                </div>
            </div>
            <div className={styles.employeeContainer}>
                <div className={styles.picture}>
                </div>
                <div className={styles.info}>
                    <p>Name</p>
                    <p>info</p>
                </div>
            </div>
            <div className={styles.employeeContainer}>
                <div className={styles.picture}>
                </div>
                <div className={styles.info}>
                    <p>Name</p>
                    <p>info</p>
                </div>
            </div>
            <div className={styles.employeeContainer}>
                <div className={styles.picture}>
                </div>
                <div className={styles.info}>
                    <p>Name</p>
                    <p>info</p>
                </div>
            </div>
            <div className={styles.employeeContainer}>
                <div className={styles.picture}>
                </div>
                <div className={styles.info}>
                    <p>Name</p>
                    <p>info</p>
                </div>
            </div>


        </div>
    );
};
export default Workers;