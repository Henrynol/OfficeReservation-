package nl.fontys.s3.officereservationsystem.domain;

public enum ReservationType {
    INDIVIDUAL,
    TEAM
}
